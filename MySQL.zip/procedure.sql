USE agence;
DELIMITER $$
create procedure ajoutCoordonees(
in numeroVoie int,
in nomVoie varchar(50),
in codePostal varchar(50),
in nomVille varchar(50),
in nomBatiment varchar(50),
in nomResidence varchar(50),
in etapeBatiment varchar(50),
in complAdresse varchar(50)
)
BEGIN 
insert into coordonnées (numéro_voie, rue, code_postal, ville, étage, résidence, batiment, complément) values
(numeroVoie, nomVoie, codePostal, nomVille, nomBatiment, nomResidence, etapeBatiment, complAdresse);
END$$
DELIMITER $$
create procedure ajoutEmploye(
in dateEmbauche int,
in prenom varchar(20),
in nom varchar(20),
in mail varchar(50),
in telephone varchar(10),
in fonctionEntreprise varchar(20),
in fkCoordonnées int
)
BEGIN
insert into employé (date_embauche, fonct_entreprise, nom, prenom, mail, telephone, fk_coordonnées) values
(dateEmbauche, prenom, nom, mail, telephone, fonctionEntreprise, fkCoordonnées);
END$$
DELIMITER $$
create procedure ajoutTransport(
in prixKm float,
in typeVehicule varchar(50),
in nomPresta varchar(20)
)
BEGIN
insert into transport (prix_km, transport_mod, prestataire) values
(prixKm, typeVehicule, nomPresta);
END$$
DELIMITER $$
create procedure ajoutEtape(
in intra bool,
in distance float,
in utilisable bool,
in fkTransport int
)
BEGIN
insert into etape(forfait, distance, utilisable, fk_transport) values
(intra, distance, utilisable, fkTransport);
END$$
DELIMITER $$
create procedure ajoutFacturation(
in nbPaiement int,
in dateAchat int,
in acquité bool,
in marge float,
in TVA float,
in fkClient int,
in fkVoyage int,
in fkEmploye int
)
BEGIN
insert into facturation(nb_paiement, achat_le, acquité, marge, TVA, fk_clients, fk_voyage, fk_employé) values
(nbPaiement, dateAchat, acquité, marge, TVA, fkClient, fkVoyage, fkEmploye);
END$$
DELIMITER $$
create procedure ajoutPaiement(
in montantPayé float,
in montantAttendu float,
in datePaiement int,
in modePaiement varchar(20),
in idClients int,
in idFacturation int
)
BEGIN
insert into paiement(montant_reçu, montant, date_paiement, mode_paiement, fk_clients, fk_facturation) values
(montantPayé, montantAttendu, datePaiement, modePaiement, idClients, idFacturation);
END$$
DELIMITER $$
create procedure ajoutVoyage(
in dateArrive int,
in dateDepart int,
in nbPtEtape int,
in fkCoordonnéesA int,
in fkCoordonnéesD int
)
BEGIN
insert into voyage(date_arrivée, date_départ, nb_pt_Etape, fk_coordonnées_a, fk_coordonnées_d) values
(dateArrive, dateDepart, nbPtEtape, fkCoordonnéesA, fkCoordonnéesD);
END$$
DELIMITER $$
create procedure ajoutClient(
in anniversaire varchar(50),
in genreClient varchar(50),
in prenomClient varchar(50),
in nomClient varchar(50),
in mailClient varchar(50),
in telephoneClient varchar(50),
in fkCoordonnéesF int,
in fkCoordonnéesL int
)
BEGIN
insert into clients (prenom, nom, telephone, sexe, mail, anniv, fk_coordonnées_f, fk_coordonnées_l) values
(prenomCLient, nomClient, telephoneCLient, genreClient, mailClient, anniversaire, fkCoordonnéesF, fkCoordonnéesL);
END$$
DELIMITER $$
create procedure ajoutVoyageur(
in ageVoyageur int,
in genreVoy varchar(20)
)
BEGIN
insert into voyageur(ageVoyageur, genre) values
(ageVoyageur, genreVoy);
END$$
DELIMITER $$
create procedure ajoutConcerne(
in nbVoyageur int
)
BEGIN
insert into concerne(nbVoyageur)values
(nbVoyageur);
END$$
DELIMITER $$
create procedure modifClientLigne(
in idClient int,
in prenomClient varchar(50),
in nomClient varchar(50),
in sexeClient varchar(50),
in mailClient varchar(50),
in telephoneClient varchar(50),
in anniversaire varchar(50),
in fk_coordonnees_f int,
in fk_coordonnees_l int
)
BEGIN
update clients
set prenom = prenomClient, nom = nomClient, sexe = sexeClient, mail = mailClient, telephone = telephoneClient, anniv = anniversaire, fk_coordonnées_f = fk_coordonnees_f, fk_coordonnées_l = fk_coordonnees_l
where id_clients = idClient;
END$$
DELIMITER $$
create procedure rechercheNomClient(
in nomClient varchar(50)
)
BEGIN
select prenom, nom, sexe, mail, telephone, anniv
from clients
where nom = nomClient;
END$$
DELIMITER $$
create procedure EditionCLient(
in idClient int,
in prenomClient varchar(50),
in nomClient varchar(50),
in sexeClient varchar(50),
in mailClient varchar(50),
in telephoneClient varchar(50),
in anniversaire varchar(50),
in fk_coordonnees_f int,
in fk_coordonnees_l int
)
BEGIN
select id_clients, prenom, nom, sexe, mail, telephone, anniv, fk_coordonnées_f, fk_coordonnées_l
from clients
where id_clients = idClient;
update clients
set prenom = prenomClient, nom = nomClient, sexe = sexeClient, mail = mailClient, telephone = telephoneClient, anniv = anniversaire, 
fk_coordonnées_f = fk_coordonnees_f, fk_coordonnées_l = fk_coordonnees_l
where id_clients = idClient;
select id_clients, prenom, nom, sexe, mail, telephone, anniv, fk_coordonnées_f, fk_coordonnées_l
from clients
where id_clients = idClient;
END$$
DELIMITER $$
create procedure modifClientNom(
in idClient int,
in nomClient varchar(50)
)
BEGIN
update clients
set nom = nomClient
where id_clients = idClient;
END$$