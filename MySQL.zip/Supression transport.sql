DELIMITER $$
CREATE PROCEDURE suppressionCascadeTransport(IN num_id INT)
BEGIN

DELETE FROM etape_voyage
WHERE fk_etape = (SELECT id_etape FROM etape WHERE fk_transport = num_id);

DELETE FROM etape
WHERE fk_transport = num_id;

DELETE FROM transport
WHERE id_transport = num_id
LIMIT 1;

END$$
DELIMITER ;