select mode_paiement, count(mode_paiement) as nbr_per,
    (count(mode_paiement)/(SELECT count(mode_paiement) FROM paiement)*100) AS "%"
from paiement
where date_paiement > unix_timestamp('2020_20_21')
group by mode_paiement;