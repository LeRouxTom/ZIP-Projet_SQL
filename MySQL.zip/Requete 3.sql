DROP VIEW IF EXISTS prix_etape;
DROP VIEW IF EXISTS forfait;
DROP VIEW IF EXISTS tva;
DROP VIEW IF EXISTS forfait_etape;
DROP VIEW IF EXISTS tout;
CREATE VIEW prix_etape AS
SELECT sum(prix_km* distance) AS prix, id_etape
FROM transport
INNER JOIN etape ON id_transport = fk_transport GROUP BY id_etape;
CREATE VIEW forfait AS
SELECT id_etape, forfait
FROM transport
INNER JOIN etape ON id_transport = fk_transport;
CREATE VIEW tva AS
SELECT id_voyage, TVA, marge
FROM facturation
INNER JOIN voyage ON voyage.id_voyage = facturation.fk_voyage;
CREATE VIEW forfait_etape AS
SELECT if(forfait = 0, prix, 2) AS prix, forfait.id_etape
FROM forfait
INNER JOIN prix_etape ON forfait.id_etape = prix_etape.id_etape;
CREATE VIEW tout AS
SELECT fk_voyage, sum(prix*tva*marge) AS prix
FROM tva
INNER JOIN etape_voyage ON id_voyage = fk_voyage
INNER JOIN forfait_etape ON fk_etape = id_etape GROUP BY fk_voyage;
SELECT avg(prix)
FROM tout;