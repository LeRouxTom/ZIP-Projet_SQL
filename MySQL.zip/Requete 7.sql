DROP VIEW IF EXISTS garde;
DROP VIEW IF EXISTS garde2;
CREATE VIEW garde AS 
SELECT fk_voyage, fk_etape, transport_mod
FROM transport
INNER JOIN etape ON id_transport = fk_transport
INNER JOIN etape_voyage ON id_etape = fk_etape where transport_mod = 'avion';
CREATE VIEW garde2 AS 
SELECT fk_voyage, fk_etape, transport_mod
FROM transport
INNER JOIN etape ON id_transport = fk_transport
INNER JOIN etape_voyage ON id_etape = fk_etape where transport_mod = 'car';
SELECT count(garde.fk_voyage)
FROM garde
INNER JOIN garde2 ON garde.fk_voyage = garde2.fk_voyage;