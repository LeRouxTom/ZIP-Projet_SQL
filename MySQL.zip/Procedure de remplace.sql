DELIMITER $$
CREATE PROCEDURE suppressionReplaceCoordonnées(
IN num_id INT,
IN test varchar(50),
IN fk_destination varchar(50))
BEGIN

update clients
set fk_coordonnées_l = 52 WHERE fk_coordonnées_l = num_id;

DELETE FROM coordonnées
WHERE id_coordonnées = num_id
LIMIT 1;

END$$
DELIMITER ;

CALL suppressionReplaceCoordonnées(1, "clients", "fk_coordonnées_l")