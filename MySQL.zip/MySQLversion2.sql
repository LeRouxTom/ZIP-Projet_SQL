DROP DATABASE IF EXISTS agence;
CREATE DATABASE agence;
USE agence;
CREATE TABLE coordonnées(
id_coordonnées int AUTO_INCREMENT KEY NOT NULL,
numéro_voie Int(10),
rue varchar(50),
code_postal varchar(5),
ville varchar(50),
étage varchar(10),
résidence varchar(50),
batiment varchar(10),
complément varchar(50) DEFAULT NULL
);
CREATE TABLE voyage(
id_voyage int AUTO_INCREMENT PRIMARY KEY NOT NULL,
date_arrivée int,
date_départ int,
nb_pt_Etape int,
fk_coordonnées_a int,
fk_coordonnées_d int,
foreign key (fk_coordonnées_a) references coordonnées(id_coordonnées),
foreign key (fk_coordonnées_d) references coordonnées(id_coordonnées)
);
CREATE TABLE transport(
id_transport int AUTO_INCREMENT KEY NOT NULL,
prix_km float,
transport_mod varchar(50),
prestataire varchar(50)
);
CREATE TABLE employé(
id_employé int AUTO_INCREMENT PRIMARY KEY NOT NULL,
date_embauche int,
fonct_entreprise varchar(50),
nom varchar(50),
prenom varchar(50),
mail varchar(50),
telephone varchar(10),
fk_coordonnées int,
foreign key (fk_coordonnées) references coordonnées(id_coordonnées)
);
CREATE TABLE clients(
id_clients int AUTO_INCREMENT PRIMARY KEY NOT NULL,
prenom varchar(20),
nom varchar (20),
sexe varchar(10),
mail varchar(50),
telephone varchar(10),
anniv varchar(15),
fk_coordonnées_f int,
fk_coordonnées_l int,
foreign key (fk_coordonnées_f) references coordonnées(id_coordonnées),
foreign key (fk_coordonnées_l) references coordonnées(id_coordonnées)
);
CREATE TABLE facturation(
id_facturation int AUTO_INCREMENT PRIMARY KEY NOT NULL,
nb_paiement Int,
achat_le int,
acquité bool,
marge float,
TVA float,
fk_clients int,
fk_employé int,
fk_voyage int,
foreign key (fk_clients) references clients(id_clients),
foreign key (fk_employé) references employé(id_employé),
foreign key (fk_voyage) references voyage(id_voyage)
);
CREATE TABLE etape(
id_etape int AUTO_INCREMENT KEY NOT NULL,
forfait bool,
distance float,
utilisable bool,
fk_transport int,
foreign key (fk_transport) references transport(id_transport)
);
CREATE TABLE paiement(
id_paiement int AUTO_INCREMENT PRIMARY KEY NOT NULL,
montant_reçu float,
montant float,
date_paiement int,
mode_paiement varchar(10),
fk_clients int,
fk_facturation int,
foreign key (fk_clients) references clients(id_clients),
foreign key (fk_facturation) references facturation(id_facturation)
);
CREATE TABLE etape_voyage(
fk_etape int,
fk_voyage int
);
CREATE TABLE voyageur(
id_voyageur int AUTO_INCREMENT PRIMARY KEY NOT NULL,
ageVoyageur varchar(20),
genre varchar(20)
);
CREATE TABLE concerne(
fk_voyage int,
fk_voyageur int,
nbVoyageur int
);