DROP VIEW IF EXISTS intra;
CREATE VIEW intra AS
SELECT sum(forfait) forfait, fk_voyage
FROM etape
INNER JOIN etape_voyage ON id_etape = fk_etape
INNER JOIN voyage ON fk_voyage = id_voyage GROUP BY fk_voyage;
SELECT forfait, count(forfait) as total, 
	(count(forfait)/(select count(forfait) from intra)*100) as "%"
    from intra GROUP BY forfait;