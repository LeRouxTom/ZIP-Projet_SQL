DELIMITER $$
CREATE PROCEDURE suppressionCascadePaiement(IN num_id INT)
BEGIN

DELETE FROM paiement
WHERE id_paiement = num_id
LIMIT 1;

DELETE FROM facturation
WHERE fk_paiement = num_id;

END$$
DELIMITER ;