SELECT MONTH(FROM_UNIXTIME(date_départ)) mois, count(date_départ) as voyage_fréquence
from voyage
group by mois
order by voyage_fréquence desc;